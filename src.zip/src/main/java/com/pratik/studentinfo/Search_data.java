package com.pratik.studentinfo;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Search_data extends AppCompatActivity {

    EditText Stext;
    Button Sbutton;
    TextView v1,v2;

    DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_data);

        databaseHelper = new DatabaseHelper(this);

        Stext = (EditText) findViewById(R.id.search_et);
        Sbutton = (Button) findViewById(R.id.search_btn);
        v1 = (TextView) findViewById(R.id.name);
        v2 = (TextView) findViewById(R.id.email);


        Sbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Cursor cursor = databaseHelper.getData(Stext.getText().toString());
                while (cursor.moveToNext())
                {
                    v1.setText(cursor.getString(1));
                    v2.setText(cursor.getString(3));

                }
            }
        });
    }
}

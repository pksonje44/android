package com.pratik.studentinfo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Add_new extends AppCompatActivity {

    EditText name,mobile,email;
    Button save;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new);

        databaseHelper = new DatabaseHelper(this);

        name = (EditText) findViewById(R.id.et1);

        mobile = (EditText) findViewById(R.id.et2);

        email = (EditText) findViewById(R.id.et3);

        save = (Button) findViewById(R.id.btn1);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean result = databaseHelper.insertdata(name.getText().toString(), Integer.parseInt(mobile.getText().toString()),email.getText().toString());

                if(result)
                    Toast.makeText(Add_new.this, "DATA INSERTED",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(Add_new.this, "DATA NOT INSERTED",Toast.LENGTH_SHORT).show();

            }

        });
    }
}
